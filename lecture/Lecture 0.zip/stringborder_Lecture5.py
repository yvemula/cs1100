# -*- coding: utf-8 -*-
"""
Created on Mon Sep 12 15:00:44 2022

@author: Yathin Vemula
"""

def frame_string(word):    
    print('*'*(len(word)+6))
    print('**',word,'**')
    return'*'*(len(word)+6)  
    


print(frame_string("Spanish Inquisition"))
print('')
print(frame_string("Ni"))
    