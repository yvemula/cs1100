# -*- coding: utf-8 -*-
"""
Created on Tue Oct  4 22:18:34 2022

@author: Yathin Vemula
"""
hd = int(input("Enter Dale's height: "))
print(hd)
he = int(input("Enter Erin's height: "))
print(he)
hs = int(input("Enter Sam's height: "))
print(hs)

d="Dale"
e="Erin"
s="Sam"

if hs<he<hd:
    print(d,e,s,sep='\n')
if hs<hd<he:
    print(e,d,s,sep='\n')
elif hd<he<hs:
    print(s,e,d,sep='\n')
elif hd<hs<he:
    print(e,s,d,sep='\n')
elif he<hs<hd:
    print(d,s,e,sep='\n')
elif he<hd<hs:
    print(s,d,e,sep='\n')