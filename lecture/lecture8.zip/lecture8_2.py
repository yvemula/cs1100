# -*- coding: utf-8 -*-
"""
Created on Fri Sep 23 21:49:42 2022

@author: Yathin Vemula
"""

values = [14, 10, 8, 19, 7, 13 ]

num=int(input("Enter a value: "))
values.append(num)
print(num)
num2=int(input("Enter another value: "))
values.append(num2)
print(num2)

print(values[2],values[-2])

difference=max(values)-min(values)
print("Difference: "+str(difference))

print("Average: {0:.1f}".format(sum(values)/len(values)))

values.sort()
median=(values[3]+values[4])/2
print("Median: {0:.1f}".format(median))