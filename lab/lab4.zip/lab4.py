# -*- coding: utf-8 -*-
"""
Created on Tue Oct  4 10:10:38 2022

@author: Yathin Vemula
"""
from PIL import Image 

im = Image.new('RGB', (1031,360), 'white') 
# use mode 'RGB', color 'white'
im1 = Image.open("cf.jpg")
im1 = im1.resize((157,256))

im2 = Image.open("hk.jpg")
im2 = im2.resize((157,256))
 # resize to the given width/height passed as a tuple
im3 = Image.open("hw.jpg")
im3 = im3.resize((157,256))
 # resize to the given width/height passed as a tuple
im4 = Image.open("im.jpg")
im4 = im4.resize((157,256))
 # resize to the given width/height passed as a tuple
im5 = Image.open("1.jpg")
im5 = im5.resize((157,256))

im6 = Image.open("2.jpg")
im6 = im6.resize((157,256))


im.paste(im1, (31,20)) 
im.paste(im2, (365,20)) 
im.paste(im3, (198,60))
im.paste(im4, (532,60)) 
im.paste(im5,(866,60))
im.paste(im6,(699,20))

im.show()
