# -*- coding: utf-8 -*-
"""
Created on Mon Sep 12 14:41:03 2022

@author: Yathin Vemula
"""    
def convert2fahren(celcius):
        fahrenheit = (celcius*1.8)+32
        return(fahrenheit) 

print("0 -> ",convert2fahren(0))
print("32 -> ",convert2fahren(32))
print("100 -> ",convert2fahren(100))

    
     
   