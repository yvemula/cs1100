# -*- coding: utf-8 -*-
"""
Created on Mon Sep 19 20:25:35 2022

@author: Yathin Vemula
"""

import math
#functions for volume of sphere and cube
def find_volume_sphere(radius):
    return 4/3*(math.pi)*pow(radius,3)
def find_volume_cube(side):
    return pow(side,3)
#we get a user input of the radius
radius = input("Enter the gum ball radius (in.) => ")
print(radius)
#we get a user input of the weekly sales
weekly_sales = input("Enter the weekly sales => ")
print(weekly_sales)
#we convert after we print otherwise weekly sales would always print with a decimal
radius = float(radius)
weekly_sales = float(weekly_sales)

#these 2 lines are used to find the number of balls that each edge can hold.
target_sales = math.ceil(1.25*weekly_sales)
num_balls = math.ceil(pow(target_sales,1/3))
# calculates the length of edge
leng = num_balls*(2*radius)
 #we print our values here
print("\nThe machine needs to hold",num_balls,"gum balls along each edge.")
print("Total edge length is","{:.2f}".format(leng),"inches.")

#we findthe leftover balls here and then print it
leftS=  pow(num_balls,3) - target_sales
print("Target sales were ",target_sales,", but the machine will hold ",leftS," extra gum balls.",sep='')

#we calculte the wasted space with the target of gum balls and the wasted space if you fill up the machine
squareVol = find_volume_cube(leng)
gumVol = find_volume_sphere(radius)
last_line1 = squareVol-(pow(num_balls,3)-leftS)*gumVol
last_line2 = squareVol-(pow(num_balls,3))*gumVol
print("Wasted space is ","{:.2f}".format(last_line1)," cubic inches with the target number of gum balls,",sep='')
print("or","{:.2f}".format(last_line2),"cubic inches if you fill up the machine.")
