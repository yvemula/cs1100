# -*- coding: utf-8 -*-
"""
Created on Tue Oct  4 11:25:35 2022

@author: Yathin Vemula
"""
from PIL import Image
def make_square(siz):
    w,h = siz.size
    if h>w:
       return siz.crop((0,0,w,w))
    if w>h:
        return siz.crop((0,0,h,h))
    return siz
   
im = Image.open("cf.jpg")
imsquare = make_square(im)
imsquare.show()

