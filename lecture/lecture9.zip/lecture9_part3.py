# -*- coding: utf-8 -*-
"""
Created on Tue Sep 27 22:17:49 2022

@author: Yathin Vemula
"""

list1=[]

value = int(input("Enter a value (0 to end): "))
print(value)

list1.append(value)

while value !=0:
    value = int(input("Enter a value (0 to end): "))
    print(value)
    list1.append(value)
    
list1.pop(len(list1)-1)
avg = sum(list1)/len(list1)
   
print("Min:",min(list1))
print("Max:",max(list1))
print("Avg: {0:.1f}".format(avg))