# -*- coding: utf-8 -*-
"""
Created on Wed Oct  5 21:10:06 2022

@author: Yathin Vemula
"""
import math
#this function finds next years bear count and berry count which determines the number of tourists for that year
def find_next(x,y,z):
    #given calculations to find th enext years count of bears and berries
    bears_next = int(y/(50*(x+1)) + x*0.60 - (math.log(1+z,10)*0.1))
    berries_next = float((y*1.5) - (x+1)*(y/14) - (math.log(1+z,10)*0.05))
    #we return the values as a tuple
    return bears_next,berries_next,z
#this function helps us determine the number of tourists we'll have based on the calculations
def num_tourists(x):
    #there will be tourists if there is anywehere between 4-15 bears
    if 4<=x and 15>=x:
        #we used nested if statements to have a more concentrated paramter. anything less than 10 but greater than 4 allows the calculation to be done
        if x<10:
            tourists = x*10000
        else:
            tourists=100000+((bears-10)*20000)
    #any other number of bears will result in zero tourists for that year
    else:
        tourists=0
    return tourists
#we get a user input of the number of bears for year one
bears = int(input("Number of bears => "))
#we print it
print(bears)
#we get a user input of the number if berries for year one
berries=(input("Size of berry area => "))
#we print it
print(berries)
#we cast berries as a float
berries=float(berries)
#if any negative values or 0 gives us 0 berries
if berries<=0:
    berries = 0
#hard code for the header
print("Year      Bears     Berry     Tourists")
berries = float(berries)
#we made empty lists to store the data for the years
bearlist = []
berrieslist = []
touristslist = []
#we use a count to make sure our while loop does it for "10 tears" 
year=1
#while loop to run 10 times
while year<=10:
    #if sufficient amount of bears, we take our values and add them to the lists
    if bears>=0:
        tourists = num_tourists(bears)
        #prints every years new count for bears berries and tourists. We use the years variable to keep trak of the years 'till 10
        print("{}\t      {}\t\t {:.1f}\t  {}".format(year,bears,berries,tourists))
        #add the values to the lists so we can pull the min and maxes from it later on
        bearlist.append(bears)
        berrieslist.append(berries)
        touristslist.append(tourists)
        #change the values of bears berries and tourists by calling the find_next function and setting the variables equal to the values in the tuple
        bears,berries,tourists = find_next(bears,berries,tourists)
        #no negative or 0 otherwise it will give us 0 berries
        if berries<0:
            berries=0
    else:
        bears=0
    #year is done at this ooint so we can add one for the next year
    year+=1
    #find the min and nax of each list
bearsMax = max(bearlist)
berriesMax = max(berrieslist)
touristsMax = max(touristslist)
bearsMin = min(bearlist)
berriesMin = min(berrieslist)
touristsMin = min(touristslist)
#we print the min and maxes in the print statement.
print("\nMin:      {}\t\t  {:.1f}\t\t{}".format(bearsMin,berriesMin,touristsMin),"\nMax:       {}\t\t  {:.1f}\t\t{}".format(bearsMax,berriesMax,touristsMax))




        

