# -*- coding: utf-8 -*-
"""
Created on Mon Sep 12 14:14:14 2022

@author: Yathin Vemula
"""
import math
pi=math.pi
radius = 5
radius2 = 32

area1 = radius**2*pi
area2 = pow(radius2,2)*pi
print("Area 1 = ",round(area1,2))
print("Area 2 = {:.2f}".format(area2))



