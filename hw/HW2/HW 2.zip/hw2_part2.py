# -*- coding: utf-8 -*-
"""
Created on Thu Sep 22 17:23:53 2022

@author: Yathin Vemula
"""
#i used lists so i wouldnt have to call each one, i could run through it
encrypted = [' a','he', 'e', 'y', 'u','an' , 'th', 'o', '9','ck']
decrypted = ['%4%','7!', '9(*9(', '*%$','@@@', '-?', '!@+3','7654', '2','%4']

#my two functions ecnyrpt and decrypt the sentence
def encrypt(word):
    wordE = word
    #use for loop with zip function for parallel iteration 
    for k, v in zip(encrypted,decrypted):
        wordE = wordE.replace(k,v)
    return wordE

def decrypt(word):
    stringD = word
    #use for loop with zip function for parallel iteration 
    for k, v in zip(reversed(encrypted),reversed(decrypted)):
        stringD = stringD.replace(v,k)
    return stringD

#user string inserted
input_str = input("Enter a string to encode ==> ")
print(input_str)
#encrypt function takes string as a parameter
stringE = encrypt(input_str)
print("\nEncrypted as ==> ",stringE)
#difference in length is the positive value of the length oif the encrypted string minus the the user input
print("Difference in length ==> ",abs(len(stringE)-len(input_str)))

#call the decrypted function with the paramters of the encrypted sentence
decrypt_str = decrypt(stringE)
print("Deciphered as ==> ",decrypt_str)

#check if the decrypt and user input is the same to see if it's reversible on the string
if decrypt_str == input_str:
    print("Operation is reversible on the string.")
else:
    print("Operation is not reversible on the string.")

