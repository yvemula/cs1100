# -*- coding: utf-8 -*-
"""
Created on Thu Sep 15 14:14:17 2022

@author: Yathin Vemula
"""
firstNum = (float)(input("Enter the first number: "))

print((int)("{:.2f}".format(firstNum)))

secondNum =(float)(input("Enter the second number: "))

print(secondNum)


if(firstNum>10 and secondNum > 10):
    print("Both are above 10.")
elif(firstNum<10 and secondNum < 10):
        print("Both are below 10.")

print("Average is","{:.2f}".format((float)(firstNum+secondNum)/2))
