# -*- coding: utf-8 -*-
"""
Created on Mon Sep 26 14:16:23 2022

@author: Yathin Vemula
"""
i=0
user_int =int(input("Enter a positive integer: "))
print(user_int)
while i<user_int: 
    print(i)
    i+=3
    
        
        
    