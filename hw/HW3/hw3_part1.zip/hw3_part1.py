# -*- coding: utf-8 -*-
"""
Created on Wed Oct  5 22:21:10 2022

@author: Yathin Vemula
"""
from syllables import find_num_syllables

paragraph = input("Enter a paragraph => ")
paragraph = paragraph.strip()
print(paragraph)

split = paragraph.split()


def ASL(paragraph):
    periods = paragraph.count('.')
    ASL = len(split)/periods
    return ASL


def PHW(paragraph):
    count = 0
    for x in split:
        if find_num_syllables(x)>=3:
            if x.count('-') == 0 and x.endswith('es') == False and x.endswith('ed') ==  False:
                count+=1
    length = len(split)
    return(count/length)*100
def listHardWord(paragraph):
    words=[]
    for x in split:
        if find_num_syllables(x)>=3:
            if x.count('-') == 0 and x.endswith('es') == False and x.endswith('ed') ==  False:
                words.append(x)
    return words

def ASYL(paragraph):
    count = 0
    for x in split:
        count = count+find_num_syllables(x)
    length = len(split)
    return count/length

GFRI = 0.4*(ASL(paragraph)+ PHW(paragraph))
FKRI = 206.835-1.015*ASL(paragraph)-86.4*ASYL(paragraph)

print("Here are the hard words in this paragraph:\n"+str(listHardWord(paragraph)))
print("Statisitics: ASL:{:.2f} PHW:{:.2f}% ASYL:{:.2f}".format((ASL(paragraph)),PHW(paragraph),ASYL(paragraph)))
print("Readability index (GFRI): {:.2f}".format(GFRI))
print("Readability index (FKri): {:.2f}".format(FKRI))
    