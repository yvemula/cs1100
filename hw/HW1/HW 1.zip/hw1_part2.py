# -*- coding: utf-8 -*-
"""
Created on Tue Sep 13 19:47:11 2022

@author: Yathin Vemula
"""
#user input of minutes
minutes = (input("Minutes ==> "))
print(minutes)
#turns minutes into an int
minutes = int(minutes)
#user input of seconds
seconds = input("Seconds ==> ")
print(seconds)
#turns seconds into an int
seconds = int(seconds)
#user input of miles
miles = input("Miles ==> ")
print(miles)
#turns miles into a float
miles=float(miles)
#user input of the target miles
goal_miles = input("Target Miles ==> ")
print(goal_miles)
#turns target miles into a float 
goal_miles = float(goal_miles)
print("")
 #converts minutes to seconds
min_to_seconds = minutes*60
#converts time with miles to pace 
pace_1 =(min_to_seconds+seconds)/miles
pace_now = int(((min_to_seconds+seconds)/miles)//60)
seconds_left = int(pace_1 - (pace_now * 60))
print("Pace is", pace_now,"minutes and",seconds_left,"seconds per mile.")
#We convert to find our miles per hour
hour_conv = (min_to_seconds+seconds)/3600
current_velocity = float(miles/hour_conv)
print("Speed is {:.2f}".format(current_velocity),"miles per hour.")

#This gets our target time it takes for the target distance with the speed
targ_min = goal_miles/current_velocity
targ_seconds = int((targ_min*3600)//60)
targ_seconds1 = int((targ_min*3600)-(targ_seconds*60))
print("Time to run the target distance of {:.2f}".format(goal_miles),"miles is",targ_seconds,"minutes and",targ_seconds1,"seconds.")

