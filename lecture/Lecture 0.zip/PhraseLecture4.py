# -*- coding: utf-8 -*-
"""
Created on Mon Sep 12 14:02:24 2022

@author: Yathin Vemula
"""
phrase = 'Things you wish you knew as a freshman'
hashtag = phrase.title()
hashtag = "#"+hashtag.replace(' ','')
print("The phrase \""+phrase+"\"\nbecomes the hashtag \""+hashtag+"\"")
