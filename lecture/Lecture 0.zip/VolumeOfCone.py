# -*- coding: utf-8 -*-
"""
Created on Tue Sep 13 10:03:26 2022

@author: Yathin Vemula
"""
height = 12.5
r = 3.4
pi = 3.14159
base_area = 2 * pi * r
volume = (1/3) * pi*height*r**2
print("Volume of a cone with")
print("height", height)
print("radius", r)

'''
The following uses formatting for the string prior to passing to the
print function call.  This is correct and creates nicely formatted
output accurate to two decimal points.  It will be explained in
Lecture 4.
'''
print("is {:.2f} cubic units".format(volume))