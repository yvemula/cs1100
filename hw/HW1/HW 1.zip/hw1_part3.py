# -*- coding: utf-8 -*-
"""
Created on Tue Sep 13 20:58:30 2022

@author: Yathin Vemula
"""
#This is a user input for a character
input_character = input("Enter frame character ==> ")
print(input_character)
input_character = input_character.strip()

#This is a user input for the height
input_H = input("Height of box ==> ")
print(input_H)
input_H = input_H.strip()

#This is a user input for the width
input_W = input("Width of box ==> ")
print(input_W+"\n")
print("Box: ")

#The variable input_Dim stores the user's dimensions
input_Dim = input_W+"x"+input_H
input_Dim = input_Dim.strip()

#This is where we create the spaces with the dimensions given
newSpace = ((int(input_W)-int(len(input_Dim)))-2)
leftS = ((int(input_W)-int(len(input_Dim)))-2)//2
rightS = int(((int(input_W)-int(len(input_Dim)))-2))- int(leftS)
newSpace = int(((int(input_W)-int(len(input_Dim)))-2))*" "
space = (int(input_W)-2)*" "

#Used to calculue the distance needed between each row and column
input_W = input_character*int(input_W)
upperRow=(((int(input_H)-2)//2)-1)
bottomRow=(int(input_H)-3)-((((int(input_H)-2)//2)-1)+1)

#This prints out the box with the user's dimensions and character
print(input_W)
print(int(upperRow)*(input_character+space+input_character+"\n")+input_character+(leftS*(" "))+input_Dim+(rightS*(" "))+input_character)
print(input_character+space+input_character)
print(bottomRow*(input_character+space+input_character+"\n")+input_W)
