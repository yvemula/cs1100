# -*- coding: utf-8 -*-
"""
Created on Mon Sep 19 20:25:35 2022

@author: Yathin Vemula
"""
input_sentence = input("Enter a sentence => ")
print(input_sentence)


#two functions that count how many happy or sad type words are in the sentence
def number_happy(sentence):
    sentence = sentence.lower()
    countH = 0
    countH = countH + sentence.count("laugh")
    countH = countH + sentence.count("happiness")
    countH = countH + sentence.count("love")
    countH = countH + sentence.count("excellent")
    countH = countH + sentence.count("good")
    countH = countH + sentence.count("smile")
    return countH
def number_sad(sentence):
        sentence = sentence.lower()
        countS = 0
        countS = countS + sentence.count("bad")
        countS = countS + sentence.count("sad")
        countS = countS + sentence.count("terrible")
        countS = countS + sentence.count("horrible")
        countS = countS + sentence.count("hate")
        countS = countS + sentence.count("problem")
        return countS
#this indicated how positive or sad it is
sentiment = ("+"*number_happy(input_sentence))+("-"*number_sad(input_sentence))
print("Sentiment: ",sentiment)
#these if statements help tell if the statement is more sad or happy or neutral
if((number_happy(input_sentence))>(number_sad(input_sentence))):
 print("This is a happy sentence.")
elif((number_sad(input_sentence))>(number_happy(input_sentence))):
 print("This is a sad sentence.")
else:
    print("This is a neutral sentence.")



