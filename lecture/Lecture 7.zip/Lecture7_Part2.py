# -*- coding: utf-8 -*-
"""
Created on Mon Sep 19 14:27:14 2022

@author: Yathin Vemula
"""

def add_tuples(x,y,z):
    sum1= x[0]+y[0]+z[0]
    sum2 = x[1]+y[1]+z[1]
    return sum1,sum2
    
    
    
print(add_tuples( (1,4), (8,3), (14,0) ))
print(add_tuples( (3,2), (11,1), (-2,6) ))