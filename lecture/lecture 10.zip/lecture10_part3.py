# -*- coding: utf-8 -*-
"""
Created on Mon Oct  3 14:08:35 2022

@author: Yathin Vemula
"""
co2_levels = [ 320.03, 322.16, 328.07, 333.91, 341.47, \
               348.92, 357.29, 363.77, 371.51, 382.47, 392.95 ]
count = 0
list_sum = sum(co2_levels)
avg_list = list_sum/len(co2_levels)
print("Average: {:.2f}".format(avg_list))

for i in co2_levels:
        if(i>avg_list):
            count+=1
print("Num above average:",count)
      
        